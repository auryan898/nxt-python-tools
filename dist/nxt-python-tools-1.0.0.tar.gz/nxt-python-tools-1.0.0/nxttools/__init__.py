__version__ = '3.1.0'
"""Next iteration of Version 3 NxtCtl.  React file added to existing files and deprecating old
projects.  
"""

__version__ = '1.0.0'
"""First iteration of Version 1 nxt-tools"""

